BUILD RUSH — CURRENT WEBSITE FILE

This package contains the current Build Rush game as index.html.

IMPORTANT:
- This is the existing game build, not a completed multiplayer PvP version.
- Bots/zombies have NOT been removed in this package.
- Real player-vs-player networking, room codes, and a multiplayer server are NOT included yet.

UPLOAD TO GITHUB PAGES:
1. Open your BuildRush repository on GitHub.
2. Choose Add file > Upload files.
3. Upload index.html (you can upload it from this ZIP after extracting it).
4. Click Commit changes.
5. In the repository, open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose branch main and folder /(root), then Save.

GitHub Pages hosts the website files; it does not provide the real-time multiplayer server.
